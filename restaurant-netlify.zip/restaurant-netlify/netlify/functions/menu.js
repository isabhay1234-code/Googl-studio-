const { json, parseBody, loadMenu, saveMenu, requireAuth } = require('./_utils');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });

  if (event.httpMethod === 'GET') {
    const menu = await loadMenu();
    return json(200, menu);
  }

  if (event.httpMethod === 'PUT') {
    const auth = requireAuth(event, ['admin']);
    if (auth.error) return auth.error;

    const nextMenu = parseBody(event);
    if (!nextMenu || !Array.isArray(nextMenu.categories)) {
      return json(400, { error: 'Invalid menu payload' });
    }

    await saveMenu(nextMenu);
    const saved = await loadMenu();
    return json(200, saved);
  }

  return json(405, { error: 'Method not allowed' });
};
