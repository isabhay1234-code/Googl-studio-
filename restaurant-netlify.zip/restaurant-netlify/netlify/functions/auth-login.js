const jwt = require('jsonwebtoken');
const { json, parseBody } = require('./_utils');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });

  const { role, password } = parseBody(event);
  const allowedRoles = ['admin', 'kitchen'];

  if (!allowedRoles.includes(role)) {
    return json(400, { error: 'Invalid role' });
  }

  const expectedPassword = role === 'admin'
    ? process.env.ADMIN_PASSWORD
    : process.env.KITCHEN_PASSWORD;

  if (!expectedPassword) {
    return json(500, { error: 'Password not configured on server' });
  }

  if (password !== expectedPassword) {
    return json(401, { error: 'Incorrect password' });
  }

  const token = jwt.sign(
    { role },
    process.env.JWT_SECRET || 'change-this-secret',
    { expiresIn: '12h' }
  );

  return json(200, { token, role });
};
