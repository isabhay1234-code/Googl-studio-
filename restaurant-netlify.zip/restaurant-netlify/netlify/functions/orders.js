const { randomUUID } = require('crypto');
const { json, parseBody, loadOrders, saveOrders, loadMenu, requireAuth } = require('./_utils');

function createOrderNumber() {
  return `ORD-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });

  if (event.httpMethod === 'GET') {
    const auth = requireAuth(event, ['kitchen', 'admin']);
    if (auth.error) return auth.error;

    const orders = await loadOrders();
    const sorted = [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return json(200, sorted);
  }

  if (event.httpMethod === 'POST') {
    const { table, items, notes } = parseBody(event);
    if (!table || !Array.isArray(items) || !items.length) {
      return json(400, { error: 'Table and items are required' });
    }

    const menu = await loadMenu();
    const catalog = new Map();
    for (const category of menu.categories) {
      for (const item of category.items) {
        catalog.set(item.id, item);
      }
    }

    const normalizedItems = items.map((entry) => {
      const menuItem = catalog.get(entry.id);
      if (!menuItem) return null;
      return {
        id: menuItem.id,
        name: menuItem.name,
        price: Number(menuItem.price),
        quantity: Math.max(1, Number(entry.quantity) || 1)
      };
    }).filter(Boolean);

    if (!normalizedItems.length) {
      return json(400, { error: 'No valid items selected' });
    }

    const total = normalizedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const orders = await loadOrders();

    const order = {
      id: randomUUID(),
      orderNumber: createOrderNumber(),
      table: String(table),
      items: normalizedItems,
      notes: String(notes || ''),
      total: Number(total.toFixed(2)),
      status: 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    orders.push(order);
    await saveOrders(orders);
    return json(201, order);
  }

  if (event.httpMethod === 'PATCH') {
    const auth = requireAuth(event, ['kitchen', 'admin']);
    if (auth.error) return auth.error;

    const { orderId, status } = parseBody(event);
    const allowedStatuses = ['new', 'accepted', 'ready', 'served'];

    if (!orderId || !allowedStatuses.includes(status)) {
      return json(400, { error: 'Invalid order update' });
    }

    const orders = await loadOrders();
    const nextOrders = orders.map((order) => order.id === orderId
      ? { ...order, status, updatedAt: new Date().toISOString() }
      : order
    );

    await saveOrders(nextOrders);
    const updated = nextOrders.find((order) => order.id === orderId);
    return json(200, updated || null);
  }

  return json(405, { error: 'Method not allowed' });
};
