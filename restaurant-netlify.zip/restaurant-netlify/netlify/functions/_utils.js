const { getStore } = require('@netlify/blobs');
const jwt = require('jsonwebtoken');

const DEFAULT_MENU = {
  restaurantName: 'Demo Bistro',
  currency: '$',
  tableCount: 12,
  categories: [
    {
      id: 'starters',
      name: 'Starters',
      items: [
        { id: 'soup', name: 'Tomato Soup', description: 'Roasted tomato soup with basil oil', price: 6.5, available: true },
        { id: 'bruschetta', name: 'Bruschetta', description: 'Toasted bread with tomato, garlic and herbs', price: 7.5, available: true }
      ]
    },
    {
      id: 'mains',
      name: 'Mains',
      items: [
        { id: 'burger', name: 'House Burger', description: 'Beef burger, cheddar, lettuce, tomato and fries', price: 14.5, available: true },
        { id: 'pasta', name: 'Creamy Mushroom Pasta', description: 'Fettuccine in mushroom cream sauce', price: 13.0, available: true }
      ]
    },
    {
      id: 'drinks',
      name: 'Drinks',
      items: [
        { id: 'cola', name: 'Cola', description: 'Chilled soft drink', price: 3.0, available: true },
        { id: 'coffee', name: 'Americano', description: 'Freshly brewed coffee', price: 3.5, available: true }
      ]
    }
  ],
  lastUpdated: new Date().toISOString()
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, OPTIONS'
    },
    body: JSON.stringify(body)
  };
}

function parseBody(event) {
  if (!event.body) return {};
  try {
    return JSON.parse(event.body);
  } catch (error) {
    return {};
  }
}

function getMenuStore() {
  return getStore('restaurant-menu');
}

function getOrdersStore() {
  return getStore('restaurant-orders');
}

async function loadMenu() {
  const store = getMenuStore();
  const menu = await store.get('current', { type: 'json' });
  if (menu) return menu;
  await store.set('current', JSON.stringify(DEFAULT_MENU));
  return DEFAULT_MENU;
}

async function saveMenu(menu) {
  const store = getMenuStore();
  await store.set('current', JSON.stringify({ ...menu, lastUpdated: new Date().toISOString() }));
}

async function loadOrders() {
  const store = getOrdersStore();
  const orders = await store.get('all', { type: 'json' });
  if (orders) return orders;
  await store.set('all', JSON.stringify([]));
  return [];
}

async function saveOrders(orders) {
  const store = getOrdersStore();
  await store.set('all', JSON.stringify(orders));
}

function requireAuth(event, allowedRoles = []) {
  const authHeader = event.headers.authorization || event.headers.Authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';

  if (!token) {
    return { error: json(401, { error: 'Missing token' }) };
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'change-this-secret');
    if (allowedRoles.length && !allowedRoles.includes(decoded.role)) {
      return { error: json(403, { error: 'Forbidden' }) };
    }
    return { user: decoded };
  } catch (error) {
    return { error: json(401, { error: 'Invalid token' }) };
  }
}

module.exports = {
  DEFAULT_MENU,
  json,
  parseBody,
  loadMenu,
  saveMenu,
  loadOrders,
  saveOrders,
  requireAuth
};
