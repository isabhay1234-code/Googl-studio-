window.RestaurantApp = (() => {
  const state = {
    menu: null,
    token: sessionStorage.getItem('staff_token') || '',
    role: sessionStorage.getItem('staff_role') || ''
  };

  async function api(path, options = {}) {
    const response = await fetch(path, {
      headers: {
        'Content-Type': 'application/json',
        ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
        ...(options.headers || {})
      },
      ...options
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'Request failed');
    }
    return data;
  }

  function setAuth(token, role) {
    state.token = token;
    state.role = role;
    sessionStorage.setItem('staff_token', token);
    sessionStorage.setItem('staff_role', role);
  }

  function clearAuth() {
    state.token = '';
    state.role = '';
    sessionStorage.removeItem('staff_token');
    sessionStorage.removeItem('staff_role');
  }

  function currencySymbol() {
    return state.menu?.currency || '$';
  }

  function money(amount) {
    return `${currencySymbol()}${Number(amount || 0).toFixed(2)}`;
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function slugify(value) {
    return String(value || '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '') || `id-${Math.random().toString(36).slice(2, 8)}`;
  }

  function showToast(message) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2600);
  }

  function formatDate(isoString) {
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(new Date(isoString));
  }

  return {
    state,
    api,
    setAuth,
    clearAuth,
    money,
    byId,
    slugify,
    showToast,
    formatDate
  };
})();
