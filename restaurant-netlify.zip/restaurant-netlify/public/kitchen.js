const KitchenApp = window.RestaurantApp;
const kitchenState = { intervalId: null };

function nextStatus(status) {
  if (status === 'new') return 'accepted';
  if (status === 'accepted') return 'ready';
  if (status === 'ready') return 'served';
  return null;
}

function nextLabel(status) {
  if (status === 'new') return 'Accept order';
  if (status === 'accepted') return 'Mark ready';
  if (status === 'ready') return 'Mark served';
  return 'Completed';
}

async function loginKitchen() {
  const password = KitchenApp.byId('kitchenPassword').value;
  const button = KitchenApp.byId('kitchenLoginBtn');
  button.disabled = true;
  button.textContent = 'Checking...';

  try {
    const result = await KitchenApp.api('/api/auth-login', {
      method: 'POST',
      body: JSON.stringify({ role: 'kitchen', password })
    });
    KitchenApp.setAuth(result.token, 'kitchen');
    KitchenApp.showToast('Kitchen page unlocked');
    showKitchenApp();
    await loadOrders();
  } catch (error) {
    KitchenApp.showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Unlock kitchen page';
  }
}

function renderOrders(orders) {
  const root = KitchenApp.byId('ordersRoot');
  if (!orders.length) {
    root.innerHTML = '<div class="empty-state">No orders yet.</div>';
    return;
  }

  root.innerHTML = orders.map((order) => {
    const next = nextStatus(order.status);
    return `
      <article class="order-card">
        <div class="order-top">
          <div>
            <h3>${order.orderNumber}</h3>
            <p>Table ${order.table} · ${KitchenApp.formatDate(order.createdAt)}</p>
          </div>
          <span class="status-chip status-${order.status}">${order.status}</span>
        </div>
        <ol class="order-items">
          ${order.items.map((item) => `<li>${item.quantity} × ${item.name}</li>`).join('')}
        </ol>
        <p><strong>Total:</strong> ${KitchenApp.money(order.total)}</p>
        <p><strong>Notes:</strong> ${order.notes || 'No notes'}</p>
        ${next ? `<button class="btn btn-primary btn-sm" data-update-order="${order.id}" data-next-status="${next}">${nextLabel(order.status)}</button>` : '<span class="pill">Done</span>'}
      </article>
    `;
  }).join('');

  document.querySelectorAll('[data-update-order]').forEach((button) => {
    button.addEventListener('click', async () => {
      const orderId = button.getAttribute('data-update-order');
      const status = button.getAttribute('data-next-status');
      button.disabled = true;
      try {
        await KitchenApp.api('/api/orders', {
          method: 'PATCH',
          body: JSON.stringify({ orderId, status })
        });
        KitchenApp.showToast(`Order updated to ${status}`);
        await loadOrders();
      } catch (error) {
        KitchenApp.showToast(error.message);
        button.disabled = false;
      }
    });
  });
}

async function loadOrders() {
  try {
    const orders = await KitchenApp.api('/api/orders');
    renderOrders(orders.filter((order) => order.status !== 'served').concat(orders.filter((order) => order.status === 'served')));
  } catch (error) {
    if (/token/i.test(error.message)) {
      hideKitchenApp();
    }
    KitchenApp.showToast(error.message);
  }
}

function showKitchenApp() {
  KitchenApp.byId('kitchenLoginCard').classList.add('hidden');
  KitchenApp.byId('kitchenApp').classList.remove('hidden');
  KitchenApp.byId('logoutKitchenBtn').classList.remove('hidden');
  KitchenApp.byId('refreshOrdersBtn').classList.remove('hidden');

  if (!kitchenState.intervalId) {
    kitchenState.intervalId = setInterval(loadOrders, 8000);
  }
}

function hideKitchenApp() {
  if (kitchenState.intervalId) {
    clearInterval(kitchenState.intervalId);
    kitchenState.intervalId = null;
  }
  KitchenApp.clearAuth();
  KitchenApp.byId('kitchenLoginCard').classList.remove('hidden');
  KitchenApp.byId('kitchenApp').classList.add('hidden');
  KitchenApp.byId('logoutKitchenBtn').classList.add('hidden');
  KitchenApp.byId('refreshOrdersBtn').classList.add('hidden');
}

function initKitchen() {
  KitchenApp.byId('kitchenLoginBtn').addEventListener('click', loginKitchen);
  KitchenApp.byId('refreshOrdersBtn').addEventListener('click', loadOrders);
  KitchenApp.byId('logoutKitchenBtn').addEventListener('click', () => {
    hideKitchenApp();
    KitchenApp.showToast('Logged out');
  });

  if (KitchenApp.state.role === 'kitchen' || KitchenApp.state.role === 'admin') {
    showKitchenApp();
    loadOrders();
  }
}

initKitchen();
