const { api, state, money, byId, showToast } = window.RestaurantApp;

const cart = new Map();

function getTableFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get('table') || '';
}

function setTableValue(value) {
  byId('tableInput').value = value;
  byId('tableBadge').textContent = value ? `Table ${value}` : 'Table not selected';
}

function addToCart(item) {
  const existing = cart.get(item.id) || { ...item, quantity: 0 };
  existing.quantity += 1;
  cart.set(item.id, existing);
  renderCart();
  showToast(`${item.name} added`);
}

function updateQty(itemId, change) {
  const entry = cart.get(itemId);
  if (!entry) return;
  entry.quantity += change;
  if (entry.quantity <= 0) {
    cart.delete(itemId);
  } else {
    cart.set(itemId, entry);
  }
  renderCart();
}

function renderMenu(menu) {
  state.menu = menu;
  byId('restaurantName').textContent = menu.restaurantName || 'Restaurant Menu';
  document.title = `${menu.restaurantName || 'Restaurant'} Menu`;

  const root = byId('menuRoot');
  root.innerHTML = menu.categories.map((category) => `
    <section class="category-block">
      <div class="category-head">
        <div>
          <h3 class="section-title">${category.name}</h3>
          <p class="section-subtitle">Freshly prepared for your table.</p>
        </div>
        <span class="pill">${category.items.filter((item) => item.available !== false).length} items</span>
      </div>
      <div class="menu-items">
        ${category.items.map((item) => `
          <article class="menu-card">
            <div>
              <h3>${item.name}</h3>
              <p>${item.description || ''}</p>
            </div>
            <footer>
              <span class="price">${money(item.price)}</span>
              ${item.available === false
                ? '<span class="pill">Sold out</span>'
                : `<button class="btn btn-primary btn-sm" data-add-item="${item.id}">Add</button>`}
            </footer>
          </article>
        `).join('')}
      </div>
    </section>
  `).join('');

  menu.categories.forEach((category) => {
    category.items.forEach((item) => {
      const button = document.querySelector(`[data-add-item="${item.id}"]`);
      if (button) {
        button.addEventListener('click', () => addToCart(item));
      }
    });
  });
}

function renderCart() {
  const entries = [...cart.values()];
  const cartItems = byId('cartItems');
  const empty = byId('cartEmpty');
  const total = entries.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);

  if (!entries.length) {
    cartItems.innerHTML = '';
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    cartItems.innerHTML = entries.map((item) => `
      <div class="cart-row">
        <div class="cart-meta">
          <strong>${item.name}</strong>
          <span class="small-note">${money(item.price)} each</span>
          <div class="qty-controls">
            <button data-minus="${item.id}">−</button>
            <strong>${item.quantity}</strong>
            <button data-plus="${item.id}">+</button>
          </div>
        </div>
        <strong>${money(item.price * item.quantity)}</strong>
      </div>
    `).join('');

    entries.forEach((item) => {
      document.querySelector(`[data-minus="${item.id}"]`)?.addEventListener('click', () => updateQty(item.id, -1));
      document.querySelector(`[data-plus="${item.id}"]`)?.addEventListener('click', () => updateQty(item.id, 1));
    });
  }

  byId('cartTotal').textContent = money(total);
}

async function submitOrder() {
  const table = byId('tableInput').value.trim();
  const notes = byId('orderNotes').value.trim();
  const items = [...cart.values()].map((item) => ({ id: item.id, quantity: item.quantity }));

  if (!table) {
    showToast('Enter table number first');
    return;
  }

  if (!items.length) {
    showToast('Add at least one item');
    return;
  }

  const button = byId('submitOrderBtn');
  button.disabled = true;
  button.textContent = 'Sending...';

  try {
    const order = await api('/api/orders', {
      method: 'POST',
      body: JSON.stringify({ table, items, notes })
    });
    cart.clear();
    renderCart();
    byId('orderNotes').value = '';
    showToast(`Order ${order.orderNumber} sent to kitchen`);
    alert(`Order ${order.orderNumber} placed successfully for Table ${order.table}.`);
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Place order';
  }
}

async function init() {
  setTableValue(getTableFromUrl());
  byId('tableInput').addEventListener('input', (event) => setTableValue(event.target.value.trim()));
  byId('submitOrderBtn').addEventListener('click', submitOrder);

  try {
    const menu = await api('/api/menu');
    renderMenu(menu);
  } catch (error) {
    byId('menuRoot').innerHTML = `<div class="empty-state">Could not load menu: ${error.message}</div>`;
  }

  renderCart();
}

init();
