const AdminApp = window.RestaurantApp;
let editorMenu = null;

function cloneMenu(menu) {
  return JSON.parse(JSON.stringify(menu));
}

function createEmptyItem() {
  return {
    id: `item-${Math.random().toString(36).slice(2, 8)}`,
    name: 'New item',
    description: '',
    price: 0,
    available: true
  };
}

function createEmptyCategory() {
  return {
    id: `category-${Math.random().toString(36).slice(2, 8)}`,
    name: 'New category',
    items: [createEmptyItem()]
  };
}

function bindSettings() {
  editorMenu.restaurantName = AdminApp.byId('restaurantNameInput').value.trim() || 'Restaurant Menu';
  editorMenu.currency = AdminApp.byId('currencyInput').value.trim() || '$';
  editorMenu.tableCount = Math.max(1, Number(AdminApp.byId('tableCountInput').value) || 1);
}

function renderMenuEditor() {
  const root = AdminApp.byId('menuEditorRoot');
  root.innerHTML = editorMenu.categories.map((category, categoryIndex) => `
    <div class="category-editor" data-category-index="${categoryIndex}">
      <div class="item-grid">
        <div class="field">
          <label>Category name</label>
          <input type="text" data-category-name="${categoryIndex}" value="${category.name}" />
        </div>
        <div class="field" style="align-self: end;">
          <button class="btn btn-danger btn-sm" data-remove-category="${categoryIndex}">Delete category</button>
        </div>
      </div>
      <div style="margin-top: 12px;">
        ${category.items.map((item, itemIndex) => `
          <div class="item-editor">
            <div class="item-grid">
              <div class="field">
                <label>Item name</label>
                <input type="text" data-item-name="${categoryIndex}:${itemIndex}" value="${item.name}" />
              </div>
              <div class="field">
                <label>Price</label>
                <input type="number" min="0" step="0.01" data-item-price="${categoryIndex}:${itemIndex}" value="${item.price}" />
              </div>
              <div class="field">
                <label>Available</label>
                <select data-item-available="${categoryIndex}:${itemIndex}">
                  <option value="true" ${item.available !== false ? 'selected' : ''}>Yes</option>
                  <option value="false" ${item.available === false ? 'selected' : ''}>No</option>
                </select>
              </div>
            </div>
            <div class="field" style="margin-top: 10px;">
              <label>Description</label>
              <input type="text" data-item-description="${categoryIndex}:${itemIndex}" value="${item.description || ''}" />
            </div>
            <div class="inline-actions">
              <button class="btn btn-outline btn-sm" data-remove-item="${categoryIndex}:${itemIndex}">Delete item</button>
            </div>
          </div>
        `).join('')}
      </div>
      <div class="inline-actions">
        <button class="btn btn-secondary btn-sm" data-add-item="${categoryIndex}">Add item</button>
      </div>
    </div>
  `).join('');

  document.querySelectorAll('[data-category-name]').forEach((input) => {
    input.addEventListener('input', () => {
      const categoryIndex = Number(input.getAttribute('data-category-name'));
      editorMenu.categories[categoryIndex].name = input.value;
    });
  });

  document.querySelectorAll('[data-item-name]').forEach((input) => {
    input.addEventListener('input', () => {
      const [categoryIndex, itemIndex] = input.getAttribute('data-item-name').split(':').map(Number);
      const item = editorMenu.categories[categoryIndex].items[itemIndex];
      item.name = input.value;
      item.id = AdminApp.slugify(input.value) || item.id;
    });
  });

  document.querySelectorAll('[data-item-price]').forEach((input) => {
    input.addEventListener('input', () => {
      const [categoryIndex, itemIndex] = input.getAttribute('data-item-price').split(':').map(Number);
      editorMenu.categories[categoryIndex].items[itemIndex].price = Number(input.value) || 0;
    });
  });

  document.querySelectorAll('[data-item-description]').forEach((input) => {
    input.addEventListener('input', () => {
      const [categoryIndex, itemIndex] = input.getAttribute('data-item-description').split(':').map(Number);
      editorMenu.categories[categoryIndex].items[itemIndex].description = input.value;
    });
  });

  document.querySelectorAll('[data-item-available]').forEach((select) => {
    select.addEventListener('change', () => {
      const [categoryIndex, itemIndex] = select.getAttribute('data-item-available').split(':').map(Number);
      editorMenu.categories[categoryIndex].items[itemIndex].available = select.value === 'true';
    });
  });

  document.querySelectorAll('[data-add-item]').forEach((button) => {
    button.addEventListener('click', () => {
      const categoryIndex = Number(button.getAttribute('data-add-item'));
      editorMenu.categories[categoryIndex].items.push(createEmptyItem());
      renderMenuEditor();
    });
  });

  document.querySelectorAll('[data-remove-item]').forEach((button) => {
    button.addEventListener('click', () => {
      const [categoryIndex, itemIndex] = button.getAttribute('data-remove-item').split(':').map(Number);
      editorMenu.categories[categoryIndex].items.splice(itemIndex, 1);
      if (!editorMenu.categories[categoryIndex].items.length) {
        editorMenu.categories[categoryIndex].items.push(createEmptyItem());
      }
      renderMenuEditor();
    });
  });

  document.querySelectorAll('[data-remove-category]').forEach((button) => {
    button.addEventListener('click', () => {
      const categoryIndex = Number(button.getAttribute('data-remove-category'));
      editorMenu.categories.splice(categoryIndex, 1);
      if (!editorMenu.categories.length) editorMenu.categories.push(createEmptyCategory());
      renderMenuEditor();
    });
  });
}

async function loginAdmin() {
  const password = AdminApp.byId('adminPassword').value;
  const button = AdminApp.byId('adminLoginBtn');
  button.disabled = true;
  button.textContent = 'Checking...';

  try {
    const result = await AdminApp.api('/api/auth-login', {
      method: 'POST',
      body: JSON.stringify({ role: 'admin', password })
    });
    AdminApp.setAuth(result.token, 'admin');
    AdminApp.showToast('Admin page unlocked');
    await loadMenuForAdmin();
    showAdminApp();
  } catch (error) {
    AdminApp.showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Unlock admin page';
  }
}

async function loadMenuForAdmin() {
  const menu = await AdminApp.api('/api/menu');
  editorMenu = cloneMenu(menu);
  AdminApp.byId('restaurantNameInput').value = editorMenu.restaurantName || '';
  AdminApp.byId('currencyInput').value = editorMenu.currency || '$';
  AdminApp.byId('tableCountInput').value = editorMenu.tableCount || 1;
  AdminApp.byId('siteBaseUrl').value = window.location.origin;
  renderMenuEditor();
}

async function saveMenu() {
  bindSettings();
  const button = AdminApp.byId('saveMenuBtn');
  button.disabled = true;
  button.textContent = 'Saving...';
  try {
    const saved = await AdminApp.api('/api/menu', {
      method: 'PUT',
      body: JSON.stringify(editorMenu)
    });
    editorMenu = cloneMenu(saved);
    renderMenuEditor();
    AdminApp.showToast('Menu saved');
  } catch (error) {
    AdminApp.showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Save menu';
  }
}

function generateQrCodes() {
  bindSettings();
  const baseUrl = AdminApp.byId('siteBaseUrl').value.trim().replace(/\/$/, '');
  if (!baseUrl) {
    AdminApp.showToast('Enter your site URL first');
    return;
  }

  const root = AdminApp.byId('qrRoot');
  root.innerHTML = '';

  for (let table = 1; table <= editorMenu.tableCount; table += 1) {
    const wrapper = document.createElement('div');
    wrapper.className = 'qr-card';
    const targetUrl = `${baseUrl}/?table=${table}`;
    wrapper.innerHTML = `
      <div id="qr-${table}"></div>
      <strong>Table ${table}</strong>
      <p class="small-note" style="word-break: break-all;">${targetUrl}</p>
    `;
    root.appendChild(wrapper);
    QRCode.toCanvas(document.getElementById(`qr-${table}`), targetUrl, { width: 150, margin: 1 });
  }

  AdminApp.showToast('QR codes generated');
}

function showAdminApp() {
  AdminApp.byId('adminLoginCard').classList.add('hidden');
  AdminApp.byId('adminApp').classList.remove('hidden');
  AdminApp.byId('saveMenuBtn').classList.remove('hidden');
  AdminApp.byId('logoutAdminBtn').classList.remove('hidden');
}

function hideAdminApp() {
  AdminApp.clearAuth();
  AdminApp.byId('adminLoginCard').classList.remove('hidden');
  AdminApp.byId('adminApp').classList.add('hidden');
  AdminApp.byId('saveMenuBtn').classList.add('hidden');
  AdminApp.byId('logoutAdminBtn').classList.add('hidden');
}

function initAdmin() {
  AdminApp.byId('adminLoginBtn').addEventListener('click', loginAdmin);
  AdminApp.byId('saveMenuBtn').addEventListener('click', saveMenu);
  AdminApp.byId('logoutAdminBtn').addEventListener('click', () => {
    hideAdminApp();
    AdminApp.showToast('Logged out');
  });
  AdminApp.byId('addCategoryBtn').addEventListener('click', () => {
    editorMenu.categories.push(createEmptyCategory());
    renderMenuEditor();
  });
  AdminApp.byId('generateQrBtn').addEventListener('click', generateQrCodes);
  AdminApp.byId('printQrBtn').addEventListener('click', () => window.print());

  ['restaurantNameInput', 'currencyInput', 'tableCountInput'].forEach((id) => {
    AdminApp.byId(id).addEventListener('input', bindSettings);
  });

  if (AdminApp.state.role === 'admin') {
    loadMenuForAdmin()
      .then(showAdminApp)
      .catch((error) => AdminApp.showToast(error.message));
  }
}

initAdmin();
